GeekOS is a tiny operating system kernel for x86 PCs.  Its main purpose
is to serve as a simple but realistic example of an OS kernel running
on real hardware.  

GeekOS is free software: see the file "COPYING" for details.
