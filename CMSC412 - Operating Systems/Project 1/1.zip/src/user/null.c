/*
 * A test program for GeekOS user mode
 */

#include <process.h>

int main() {
    Null();

    for (;;);

    return 0;
}
