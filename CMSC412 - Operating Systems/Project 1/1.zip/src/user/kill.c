#include <conio.h>
#include <process.h>
#include <string.h>
#include <signal.h>

int main(int argc, char **argv) {
        int pid, ret, i = 1;
        while(i < argc){
			pid = atoi(argv[i]);
			ret = Kill(pid, 0);
			if(ret < 0) //error killing process, exit
					return ret;
			i++;
		}
        return 0;
}
