#ifndef _INCLUDED_SEM_H
#define _INCLUDED_SEM_H
#ifdef GEEKOS
int Sys_Open_Semaphore(struct Interrupt_State *state);
int Sys_P(struct Interrupt_State *state);
int Sys_V(struct Interrupt_State *state);
int Sys_Close_Semaphore(struct Interrupt_State *state);
#endif
#endif
