#include <geekos/syscall.h>
#include <conio.h>
#include <string.h>

int main(int argc, char **argv) {
	int i, lim, numCalls;
	lim = atoi(argv[1]);
	numCalls = atoi(argv[2]);
	if(numCalls > 0 && argc == 3 && lim >= 0){
		Limit(0, lim);
		for(i = 0; i < numCalls; i++)
			Null();
		
		return 0;
	}
	return -1;
}
