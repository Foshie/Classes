#include <conio.h>
#include <process.h>
#include <fileio.h>

int main(int argc, char *argv[]){
  int retC;
  Format("ide1", "gosfs");
  Print("Formatted\n");
  Mount("ide1", "/d", "gosfs");
  Print("Mounted\n");
  
  retC = Create_Directory("/d/dir1");
  Print("returns with %d\n", retC);
  return 0;
}
