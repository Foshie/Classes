//test format system call
#include <conio.h>
#include <process.h>
#include <fileio.h>

int main(int argc, char *argv[]) {
    int ret;

    if (argc != 3) {
        Print("usage: mount <blockdev> <fstype>\n");
        Exit(1);
    }

    ret = Format(argv[1], argv[2]);
    if (ret != 0) {
        Print("Format failed: %s\n", Get_Error_String(ret));
        Print("%d\n",ret);
        Exit(1);
    }

    return 0;
}