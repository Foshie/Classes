
#include <conio.h>
#include <process.h>
#include <fileio.h>
#include <string.h>
#include <geekos/projects.h>

int main(int argc, char *argv[]){
	int ret1, ret2;
	Format("ide1", "gosfs");
	Print("Formatted\n");
	Mount("ide1", "/d", "gosfs");
	Print("Mounted\n");	
	
	ret1= Open("/d/InexistentFile", O_READ);
	ret2 = Open("/d/ExistentFile", O_READ|O_CREATE);
	Print("File 1, /d/InexistentFile was ");
	if(ret1 < 0)
		Print("not ");
	Print("made.\n");
	Print("File 2, /d/ExistentFile was ");
	if(ret2 < 0)
		Print("not ");
	Print("made.\n");
	return 0;
}