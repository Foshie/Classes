#include <limits.h>
#include <geekos/errno.h>
#include <geekos/kassert.h>
#include <geekos/screen.h>
#include <geekos/malloc.h>
#include <geekos/string.h>
#include <geekos/bitset.h>
#include <geekos/synch.h>
#include <geekos/bufcache.h>
#include <geekos/list.h>
#include <geekos/gosfs.h>
#include <geekos/vfs.h>
#include <geekos/string.h>
#include <geekos/bitset.h>
#include <geekos/user.h>
#include <geekos/fileio.h>
#define MAX_PREFIX_LEN 16
struct GOSFS_Instance {
  GOSFSsuperblock *super_block;
};
int readBlock(struct Block_Device *dev, int blockNum, void *buf);
int writeBlock(struct Block_Device *dev, int blockNum, void *buf);
/*
=========================================================================================================
                     Helper Functions
=========================================================================================================
 */
int readBlock(struct Block_Device *dev, int blockNum, void *buf){
  int i;
  for(i = 0; i < 8; i++){
    if(Block_Read(dev, blockNum*8+i, buf+512*i) < 0)
      return -1;
  }
  return 0;
}

int writeBlock(struct Block_Device *dev, int blockNum, void *buf){
  int i;
  for(i = 0; i < 8; i++){
    if(Block_Write(dev, blockNum*8+i, buf+512*i) < 0)
      return -1;
  }
  return 0;
}

/*
 * Unpack a path into prefix and suffix.
 * The prefix determines which mounted filesystem
 * the path resides in.  The suffix is the path within
 * the filesystem.
 * Params:
 *   path - the complete path
 *   prefix - buffer where prefix will be stored
 *   pSuffix - stores the pointer to the suffix part of path
 * Returns: true if path is valid, false if not
 */
static bool Unpack_Path(const char *path, char *prefix, const char **pSuffix) {
    char *slash;
    size_t pfxLen;


    /* Path must start with '/' */
    if (*path != '/')
        return false;
    ++path;

    /* Look for the initial slash. */
    slash = strchr(path, '/');
    if (slash == 0) {
        /*
         * Special case: path of the form "/prefix".
         * It resolves to the root directory of
         * the filesystem mounted on the prefix.
         */
        pfxLen = strlen(path);
        if (pfxLen == 0 || pfxLen > MAX_PREFIX_LEN)
            return false;
        strcpy(prefix, path);
        *pSuffix = "/";
    } else {
        /*
         * Determine length of file prefix.
         * It needs to be non-zero, but less than MAX_PREFIX_LEN.
         */
        pfxLen = slash - path;
        if (pfxLen == 0 || pfxLen > MAX_PREFIX_LEN)
            return false;

        /* Format the path prefix as a string */
        memcpy(prefix, path, pfxLen);
        prefix[pfxLen] = '\0';

        /*
         * Set pointer to "suffix", i.e., the rest of the path
         * after the prefix
         */
        *pSuffix = slash;
    }

    KASSERT(**pSuffix == '/');

    return true;
}

/*
==============================================================================
                    Public Functions
==============================================================================
*/
/*
 * Format a drive with GOSFS.
 *
 * Formats a drive with GOSFS;
 * don't need to support formatting with PFAT ; 
 * don't need to format in init code; 
 * so you can save your data between sessions
 
	On sucess, return 0.
	On Error, return -1:
 * illegal value for drive (it must work with 1, higher is optional)
 * drive is in use, i.e. mounted
 */
int GOSFS_Format(struct Block_Device *blockDev) {
  GOSFSsuperblock *super_block;
  GOSFSfileNode *rootFN;
  GOSFSdirectory *root;
  int numBlocks = 0, bitmapSize;
  void *freeMap;
  super_block = Malloc(BLOCK_SIZE);
  if(super_block == NULL)
    return -1;
  memset(super_block, '\0', BLOCK_SIZE);
  
  //Get drive's size, convert it in # of blocks.
  numBlocks = Get_Num_Blocks(blockDev);
  
  //Figure out free blocks bitmap size, mark them all free
  bitmapSize = numBlocks/8;
	super_block->size = bitmapSize;
  freeMap = Create_Bit_Set(bitmapSize);
  if(freeMap == NULL)
    return -1;
  
  //Create a valid, but empty directory.  That will be the root directory.  Make Root Dir Pointer point to it.
  root = Malloc(BLOCK_SIZE);
  if(root == NULL)
    return -1;
  memset(root, '\0', BLOCK_SIZE);
  super_block->rootDir = 1;
  
  //Mark Superblock and block for root directory as used in the Free Blocks Bitmap
  Set_Bit(freeMap, 0);//superblock
  Set_Bit(freeMap, 1);//root directory
  
  memcpy(super_block->freeMap, freeMap, bitmapSize);
  //If everything went OK, write the Magic.  Now the disk is ready to be mounted and used
  super_block->magic = GOSFS_MAGIC;

  super_block->rootFN.blocks[0] = 1;
  super_block->rootFN.isDirectory = 1;
  super_block->rootFN.isUsed = 1;
  super_block->rootFN.acls[0].uid = 0;
  if(writeBlock(blockDev, 0, super_block) <0)
    return -1;
  if(writeBlock(blockDev, 1, root) < 0)
    return -1;
  
  Free(super_block);
  Free(root);
  
  return 0;
}

/*
 * Mount_Point_Ops for GOSFS filesystem.
 */
struct Mount_Point_Ops s_gosfsMountPointOps = {
    GOSFS_Open,
    GOSFS_Create_Directory,                          /* Create_Directory() */
    GOSFS_Open_Directory,
    GOSFS_Stat,
    GOSFS_Sync,
    GOSFS_Delete,                           /* Delete */
    GOSFS_SetSetUid,
    GOSFS_SetAcl
};

/*
 * Your Mount function should not "validate" the filesystem settings 
 * except for magic and version fields, and that block size is 
 * support-able (a multiple of 512, or 512/1024/4096 at least). 
 * Other items, e.g., the number and start location of inodes 
 * and the total number of blocks, can be arbitrary.
 
 * Mount GOSFS. Return 0 on success, return -1 on failure.
 * - Check that the magic number is correct.
  - a filesystem already mounted under name
	- illegal value for one of the parameters
 */
int GOSFS_Mount(struct Mount_Point *mountPoint) {
  struct GOSFS_Instance *instance = 0; 
  int i;
  /* Allocate instance */
  instance = (struct GOSFS_Instance *) Malloc(sizeof(*instance));
  if(instance == 0)
    return -1;
  memset(instance, '\0', sizeof(*instance));
  
  /*Allocate superblock buffer*/
  instance->super_block = Malloc(BLOCK_SIZE);
  if(instance->super_block == NULL)
    return -1;
  if(readBlock(mountPoint->dev, 0, instance->super_block) < 0)
    return -1;
  
  //Check magic number
  if(instance->super_block->magic != GOSFS_MAGIC)
    return -1;
  mountPoint->ops = &s_gosfsMountPointOps;
  mountPoint->fsData = instance;
  return 0;

}

/*
 * Get metadata for given File. Called with a file descriptor.
 */
int GOSFS_FStat(struct File *file, struct VFS_File_Stat *stat) {
  return -1;
}

static struct File_Ops s_gosfsFileOps = {
  &GOSFS_FStat,
  &GOSFS_Read,                          /* Read */
  &GOSFS_Write,                          /* Write */
  &GOSFS_Seek,                          /* Seek */
  &GOSFS_Close,
  &GOSFS_Read_Entry,
};
/*
 * Open a file with the given name and mode.
 * If a directory does not exist from the file path, do not create.  Return -1.
 * Return -1 when a directory is targeted.
 * Return > 0 on success, < 0 on failure (e.g. does not exist).
 */
int GOSFS_Open(struct Mount_Point *mountPoint, const char *path, int mode,
               struct File **pFile) {
  char prefix[1024], *suff = 0;
  int i, flag = 0,  parentBit,j=0; 
  int aclsFlag = 0;
  GOSFSsuperblock *s_block; 
  GOSFSdirectory *currDir; 
  GOSFSfileNode *fileNode, parentNode;
  GOSFSptr *filePTR; 
  struct File *file;
  //Get directory path resides in. 
  //start at root directory
  s_block = Malloc(BLOCK_SIZE);
  if(s_block == 0)
    return -1;
  memset(s_block, '\0', BLOCK_SIZE);
  currDir = Malloc(BLOCK_SIZE);
  if(currDir == 0)
    return -1;
  memset(currDir, '\0', BLOCK_SIZE);
  if(readBlock(mountPoint->dev, 0, s_block)< 0)
    return -1;
  //Start at root directory
  parentBit = s_block->rootDir;
  if(readBlock(mountPoint->dev, parentBit, currDir) < 0)
    return -1;
  parentNode = s_block->rootFN;
  if(strlen(path) >= 1024)
    return -1;
  
  strcpy(suff, path);
  Print("Open - %s\n", path);
  //Find Path for file's parent directory.  If doesn't exist will return with -1.
  //If it does, sets the curr directory
  while(Unpack_Path(suff, prefix, &suff)){ 
    Print("prefix- %s and suffix - %s\n", prefix, suff);
    //we've found the directory and have found the file's name. 
    if(strcmp(suff, "/") == 0) 
      break; 
    //Search in Current directory for directory name 
    for(i = 0; i < MAX_FILES_PER_DIR; i++){ 
      if(currDir->files[i].isUsed){ 
	Print("file name: %s", currDir->files[i].name);
	if(strcmp(currDir->files[i].name, prefix) == 0){ 
 	  //check if the value is a file or directory. 
	  if(currDir->files[i].isDirectory == 0) 
	    return -1;
	  else{ 
	    //change to this directory. 
	    flag = 1;
	    parentBit = currDir->files[i].blocks[0]; 
	    parentNode = currDir->files[i];
	    readBlock(mountPoint->dev, currDir->files[i].blocks[0], currDir); 
	    break; 
	  } 
	} 
      } 
    }
    if(flag == 0){
      Print("Path was not found\n");
      return -1;
    }
  }
  Print("Get's here.\nlooking for file %s in current directory %s\n", prefix, parentNode.name);
  flag = 0;
  //Check if file exists in current directory.  If it is a directory, error out.
  //If it doesn't exist, create it.  If it does exist, open it.
  for(i = 0; i < MAX_FILES_PER_DIR; i++){
    Print("i - %d\n", i);
    if(currDir->files[i].isUsed){
      //Something exists
      Print("file/directory in currDir: %s\n", currDir->files[i].name);
      if(strcmp(currDir->files[i].name, prefix) == 0){
	//is it a directory?
	//if(currDir->files[i].isDirectory == 1)
	//return -1;
	//else{
	flag = 1;
	break;
	//}				
      }
    }
  }
  Print("current uid: %d\nfound? %d\n", g_currentThread->userContext->uid, flag);
  //Print("path: %s, file name: %s, flag: %d\n", path, suffix, flag);
  if(flag == 0){
    //File does not exist.
    if(!(O_CREATE & mode)){//create bit is not set.
      Print("O_CREATE not set in mode\n");
      return -1;
    }
    //does uid have access to write to parent directory?
    for(j = 0; j < VFS_MAX_ACL_ENTRIES; j++){
      if(g_currentThread->userContext->uid == 0){
	break;
      }
      if(parentNode.acls[j].uid == g_currentThread->userContext->uid){
	if(parentNode.acls[j].permission & O_WRITE){
	  break;
	}else{
	  Print("Permissions not enough\n");
	  return -1;
	}
      } 
    }
    Print("acls Flag = 1\n");
    //find unused slot in directory.
    for(i = 0; currDir->files[i].isUsed && i < MAX_FILES_PER_DIR; i++);
    
    //Create file
    fileNode = &currDir->files[i];
    memset(fileNode, '\0', sizeof(GOSFSfileNode));
    fileNode->isUsed = 1;
    fileNode->isDirectory = 0;
    strcpy(fileNode->name, prefix);
    fileNode->acls[0].uid = g_currentThread->userContext->uid;
		Print("uid of owner: %d\n", fileNode->acls[0].uid);
    //Update directory
    writeBlock(mountPoint->dev, parentBit, currDir);
  }else{
    
    Print("Open- owner's ID: %d\n", currDir->files[i].acls[0].uid);
    //Get file's permissions
    //If the uid does not exist, then return -1;
    for(j = 0; j < VFS_MAX_ACL_ENTRIES; j++){
      if(g_currentThread->userContext->uid == 0){
	aclsFlag = 1;
	break;
      }
      if(g_currentThread->userContext->uid == currDir->files[i].acls[j].uid){
	if(j == 0){
	  aclsFlag = 1;
	  break;
	}
	mode = mode & ~O_CREATE;
	if((currDir->files[i].acls[j].permission | mode) == currDir->files[i].acls[j].permission){
	  aclsFlag = 1;
	  break;
	}
	Print("Permissions not enough.\n");
	return -1;
      }
    }
    if(aclsFlag == 0){
      Print("Permission to open file not existent with current uid: %d\n", g_currentThread->userContext->uid);
      return -1;
    }

    fileNode = &currDir->files[i];
    
  }
  filePTR = Malloc(sizeof(GOSFSptr));
  if(filePTR == NULL)
    return -1;
  memset(filePTR, '\0', sizeof(GOSFSptr));
  filePTR->blockNum = parentBit;
  filePTR->offset = i;
  filePTR->node = *fileNode;
  file = Allocate_File(&s_gosfsFileOps, 0, currDir->files[i].size, filePTR, mode, mountPoint);
  if(file == NULL)
    return -1;
  Free(currDir);
  Free(s_block);
  *pFile = file;
  return 0; 
 fail1: 
  Free(filePTR); 
 fail2: 
  Free(currDir); 
 fail3: 
  Free(s_block); 
  return -1;
}
//Returns the block # in disk where the block from the file is stored.
//If the block isn't allocated.  Allocate it.
int Get_Block(struct File *file, int blockNum, void *block){
  GOSFSfileNode *fileNode = &((GOSFSptr *)file->fsData)->node, *buf;
  int num, totalBits = ((struct GOSFS_Instance *)file->mountPoint->fsData)->super_block->size/8;
  
  //direct blocks
  if(blockNum < 8){
    num = fileNode->blocks[blockNum];
    if(num == 0){ //Block hasn't been allocated yet.
      num = Find_First_Free_Bit(((struct GOSFS_Instance *)file->mountPoint->fsData)->super_block->freeMap, totalBits);
			fileNode->blocks[blockNum] = num;
			Set_Bit(((struct GOSFS_Instance *)file->mountPoint->fsData)->super_block->freeMap, totalBits);
			memset(block, '\0', BLOCK_SIZE);			
    }else
      readBlock(file->mountPoint->dev, num, block);
  }else//1 and 2nd level indirect not implemented.
		return -1;
	//update disk
	buf = Malloc(BLOCK_SIZE);
	readBlock(file->mountPoint->dev, ((GOSFSptr *)file->fsData)->blockNum, buf);
	memcpy(buf + ((GOSFSptr *)file->fsData)->offset, &((GOSFSptr *)file->fsData)->node, sizeof(GOSFSfileNode));
	writeBlock(file->mountPoint->dev, ((GOSFSptr *)file->fsData)->blockNum, buf);
	Free(buf);
  return num;
}

/*
 * Read data from current position in file.
 * Return > 0 on success, < 0 on failure.
 */
int GOSFS_Read(struct File *file, void *buf, ulong_t numBytes) {
  GOSFSfileNode *fileNode;
  int block, byte, p_block,count;
  void *curr;
  if(!(file->mode & O_READ)){
    Print("Read bit not set\n");
    return -1;
  }
  fileNode= &((GOSFSptr *)file->fsData)->node;
  if(fileNode->isDirectory)
    return -1;
  block = file->filePos / BLOCK_SIZE; //which block
  byte = file->filePos % BLOCK_SIZE;  //where in the block
  curr= Malloc(BLOCK_SIZE);
  if(curr == NULL)
    return -1;
  
  for(count = 0; count < numBytes; ){
    //Find physical block to read
    p_block = Get_Block(file, block, curr);
    if(p_block == -1){
      Print("block not allocated at %d\n", p_block);
      return -1; 
    }
    if((file->endPos - (file->filePos + count) < numBytes - count) && (file->endPos - (file->filePos + count) < BLOCK_SIZE - byte)){
      memcpy((char *)buf + count, ((char *)curr) + byte, file->endPos - (file->filePos + count));
      count += file->endPos - (file->filePos + count);
      break;
    }else if((file->endPos - (file->filePos + count) >= numBytes - count) && (BLOCK_SIZE - byte > numBytes - count)){
      memcpy((char *)buf + count, ((char *)curr) + byte, numBytes - count);
      count = numBytes;
      break;
    }else
      //read from current filePos to end of block.
      memcpy((char *) buf + count, ((char *)curr) + byte, BLOCK_SIZE - byte);
    
    
    count += BLOCK_SIZE - byte;
    byte = 0;
    block++;
  }
	Free(curr);
	file->filePos += count;
	return count;
  
}

/*
 * Write data to current position in file.
 * Return > 0 on success, < 0 on failure.
 */
int GOSFS_Write(struct File *file, void *buf, ulong_t numBytes) {
 GOSFSfileNode *fileNode, *buffer;
  int block, byte, p_block, numWritten = 0;
  void *curr;
  if(!(file->mode & O_WRITE)){
    Print("Write bit not set\n");
    return -1;
  }
	fileNode= &((GOSFSptr *)file->fsData)->node;
  if(fileNode->isDirectory){
		Print("Cannot write to directory\n");
    return -1;
	}
  block = file->filePos / BLOCK_SIZE; //which block
  byte = file->filePos % BLOCK_SIZE;  //where in the block
  curr= Malloc(BLOCK_SIZE);
  if(curr == NULL)
    return -1;
	
	while(numWritten < numBytes){
		p_block = Get_Block(file, block, curr);
		if(BLOCK_SIZE - byte > numBytes - numWritten){
			memcpy(((char *)curr) + byte, ((char *)buf) + numWritten, numBytes - numWritten);
			writeBlock(file->mountPoint->dev, p_block, curr);
			numWritten = numBytes;
			break;
		}else
			memcpy(((char *)curr) + byte, ((char *)buf) + numWritten, BLOCK_SIZE - byte);
			
		numWritten += BLOCK_SIZE - byte;
		block++;
		byte = 0;
		writeBlock(file->mountPoint->dev, p_block, curr);
	}
	Free(curr);
	file->filePos += numWritten;
	if(file->filePos > file->endPos){
		file->endPos = file->filePos;
		fileNode->size = file->endPos;
		
		buffer = Malloc(BLOCK_SIZE);
		readBlock(file->mountPoint->dev, ((GOSFSptr *)file->fsData)->blockNum, buffer);
		memcpy(buffer + ((GOSFSptr *)file->fsData)->offset, &((GOSFSptr *)file->fsData)->node, sizeof(GOSFSfileNode));
		writeBlock(file->mountPoint->dev, ((GOSFSptr *)file->fsData)->blockNum, buffer);
		Free(buffer);
	}
	return numWritten;
}

/*
 * Get metadata for given file. Need to find the file from the given path.
 */
int GOSFS_Stat(struct Mount_Point *mountPoint, const char *path, struct VFS_File_Stat *stat) {
  char *suff=0, prefix[1024];  
  GOSFSsuperblock *s_block;
  GOSFSfileNode parentNode, gosfsFile;
  GOSFSdirectory *currDir;
  int flag = 0, i, bitNum, parentBit, j = 0;
  Print("Stat - path: %s\n", path);
  if(strcmp(path, "/") == 0)
    return -1;
  //start at root directory
  s_block = Malloc(BLOCK_SIZE);
  if(s_block == 0)
    return -1;
	memset(s_block, '\0', BLOCK_SIZE);
  currDir = Malloc(BLOCK_SIZE);
  if(currDir == 0)
    return -1;
      memset(currDir, '\0', BLOCK_SIZE);
  if(readBlock(mountPoint->dev, 0, s_block)< 0)
    return -1;
  //Start at root directory
  parentBit = s_block->rootDir;
  parentNode = s_block->rootFN;
  if(readBlock(mountPoint->dev, parentBit, currDir) < 0)
    return -1;
  strcpy(suff, path);

  while(Unpack_Path(suff, prefix, &suff)){
    if(strcmp("/", suff) == 0)
      break;
    //Get filenode's directory struct
    /*
      Find prefix in curr directory
      -Look in blocks[0] for an existing directory. 
      -If exists, return -1 if it is a file, or set as new directory.
      -If doesnt exist, create a directory.
    */
	//Print("%s\n", prefix);
    for(i = 0; i < MAX_FILES_PER_DIR; i++){
      if(currDir->files[i].isUsed){
	if(strcmp(currDir->files[i].name, prefix) == 0){
	  if(currDir->files[i].isDirectory == 0)
	    return -1;
	  else{
	    flag = 1;
	    parentBit = currDir->files[i].blocks[0];
	    parentNode=  currDir->files[i];
	    readBlock(mountPoint->dev, currDir->files[i].blocks[0], currDir);
	    break;	
	  }
	}
      }
    }
    if(flag == 0){
      Print("Path could not be found\n");
      return -1; //name does not exist
    }
  }
  int found = 0;
  for(i = 0; i < MAX_FILES_PER_DIR; i++){
    if(currDir->files[i].isUsed){
      //Something exists
      if(strcmp(currDir->files[i].name, prefix) == 0){
	found = 1;
	break;
      }				
    }
  }
  if(found == 0){
    Print("File not found in current directory. \n");
    return -1;
  }
  //Search for file in currDir
  gosfsFile = currDir->files[i];
  stat->size = gosfsFile.size;
  stat->isDirectory = gosfsFile.isDirectory;
  stat->isSetuid = gosfsFile.isSetUid;
  Print("Stat values\n");
  Print("stat's size: %d\n isDirectory: %d\n isSetuid: %d\n", stat->size,
	stat->isDirectory, stat->isSetuid);
  memcpy(&(stat->acls),&(gosfsFile.acls), sizeof(stat->acls));
  return 0;
}

/*
 * Synchronize the filesystem data with the disk
 * (i.e., flush out all buffered filesystem data).
 */
int GOSFS_Sync(struct Mount_Point *mountPoint) {
  return 0;
}

/*
 * Close a file.
 */
int GOSFS_Close(struct File *file) {
    return 0;
}

/*
 * Create a directory named by given path.
 */
/*
  Should create directories recursively if needed, e.g. CreateDirectory("/d/d1/d2/d3/d4")
will create d1 inside of d, d2 inside of d1, etc.  If they don't exist already. 

This opration should be atomic, in the sense that either the whole directory chain is created or no directory is created.

Return: 0 on sucess
       -1 if name already exists as file or directory
          regular file encountered on the path to name.
*/
int GOSFS_Create_Directory(struct Mount_Point *mountPoint, const char *path) {
  char *suff=0, prefix[1024];
  GOSFSsuperblock *s_block;
  GOSFSfileNode parentNode;
  GOSFSdirectory *currDir, *createD;
  int flag = 0, i, bitNum, parentBit, j = 0;
  Print("Create Directory.%s\n", path);
  //start at root directory
  s_block = Malloc(BLOCK_SIZE);
  if(s_block == 0)
    return -1;
	memset(s_block, '\0', BLOCK_SIZE);
  currDir = Malloc(BLOCK_SIZE);
  if(currDir == 0)
    return -1;
      memset(currDir, '\0', BLOCK_SIZE);
  if(readBlock(mountPoint->dev, 0, s_block)< 0)
    return -1;
  //Start at root directory
  parentBit = s_block->rootDir;
  parentNode = s_block->rootFN;
  if(readBlock(mountPoint->dev, parentBit, currDir) < 0)
    return -1;
  if(strlen(path) >= 1024)
	return -1;
  strcpy(suff, path);
  
  while(Unpack_Path(suff, prefix, &suff)){
	flag = 0;
    //Get filenode's directory struct
    /*
      Find prefix in curr directory
      -Look in blocks[0] for an existing directory. 
      -If exists, return -1 if it is a file, or set as new directory.
      -If doesnt exist, create a directory.
    */
	//Print("%s\n", prefix);
    for(i = 0; i < MAX_FILES_PER_DIR; i++){
      if(currDir->files[i].isUsed){
	if(strcmp(currDir->files[i].name, prefix) == 0){
	  if(currDir->files[i].isDirectory == 0)
	    return -1;
	  else{
	    flag = 1;
	    parentBit = currDir->files[i].blocks[0];
	    parentNode=  currDir->files[i];
	    readBlock(mountPoint->dev, currDir->files[i].blocks[0], currDir);
	    break;	
	  }
	}
      }
    }
    //Could not find it in current directory, create directory.
    if(flag == 0){
      Print("Create directory - parent's owner's node: %d, curr uid: %d\n", parentNode.acls[0].uid, g_currentThread->userContext->uid);
      //Does current uid have access to writing to parent ID?
      for(j = 0; j < VFS_MAX_ACL_ENTRIES; j++){
	if(g_currentThread->userContext->uid == 0){
	  break;
	}
	if(g_currentThread->userContext->uid == parentNode.acls[j].uid){
	  if(j == 0 || parentNode.acls[j].permission & O_WRITE){
	    break;
	  }else{
	    Print("Create Directory - permissions not enough\n");
	    return -1;
	  }
	}
	
      }
      
      for(i = 0; i < MAX_FILES_PER_DIR; i++){
	if(currDir->files[i].isUsed == 0)
	  break;
      }
      if(i== MAX_FILES_PER_DIR)
	return -1;
      Print("%d\n",i);
      createD = Malloc(BLOCK_SIZE);
      if(createD == NULL)
	return -1;
      memset(createD, '\0', BLOCK_SIZE);
      //Find first free bit.
      bitNum = Find_First_Free_Bit(s_block->freeMap, 1024 * 8);
      if(bitNum < 0)
	return -1;
      //Set fields in newly made filenode
      strcpy(currDir->files[i].name, prefix);
      currDir->files[i].isUsed = 1;
      currDir->files[i].isDirectory = 1;

      currDir->files[i].blocks[0] = bitNum;
      currDir->files[i].acls[0].uid = g_currentThread->userContext->uid;
      
      //Set bit in super block
      //******how to deal with different mappings
      Set_Bit(s_block->freeMap, bitNum);
      //Write blocks
      writeBlock(mountPoint->dev, 0, s_block);
      writeBlock(mountPoint->dev, parentBit, currDir);
      writeBlock(mountPoint->dev, bitNum, createD);
      parentBit = bitNum;
      currDir = createD;
    }else if(strcmp(suff, "/") == 0){//No more cases.  Directory already exists.
      return -1;
    }
  }
  
  return 0;
}

/*
 * Open a directory named by given path.
 */
int GOSFS_Open_Directory(struct Mount_Point *mountPoint, const char *path,
                         struct File **pDir) {
  char *suffix, prefix[1024];
  GOSFSsuperblock *s_block;
  GOSFSdirectory *currDir, *createD;
  int flag = 0, i, bitNum, parentBit;
  struct File *file;
  
  GOSFSptr *filePTR;
  Print("Open Directory - %s\n", path);
  //start at root directory
  s_block = Malloc(BLOCK_SIZE);
  if(s_block == 0)
    return -1;
  memset(s_block, '\0', BLOCK_SIZE);
  currDir = Malloc(BLOCK_SIZE);
  if(currDir == 0)
    return -1;
  memset(currDir, '\0', BLOCK_SIZE);
  if(readBlock(mountPoint->dev, 0, s_block)< 0)
    return -1;
  //Start at root directory
  parentBit = s_block->rootDir;
  if(readBlock(mountPoint->dev, parentBit, currDir) < 0)
    return -1;
  
  strcpy(suffix, path);
  while(Unpack_Path(suffix, prefix, &suffix)){

	//Looks for directory in current directory.
    for(i = 0; i < MAX_FILES_PER_DIR; i++){
      if(currDir->files[i].isUsed){
	if(strcmp(currDir->files[i].name, prefix) == 0){
	  if(currDir->files[i].isDirectory == 0)
	    return -1;
	  else{
	    flag = 1;
	    parentBit = currDir->files[i].blocks[0];
	    readBlock(mountPoint->dev, currDir->files[i].blocks[0], currDir);
	    break;	
	  }
	}
      }
    }
    if(flag == 0){
      Print("Directory not found\n");
      return -1;
    }
  }
  if(flag == 0){
    Print("Directory not found.\n");
    return -1;
  }
  filePTR = Malloc(sizeof(GOSFSptr));
  if(filePTR == NULL)
    return -1;
  filePTR->blockNum = parentBit;
  filePTR->node = currDir->files[i];
  filePTR->offset = i;
  file = Allocate_File(&s_gosfsFileOps, 0, currDir->files[i].size, filePTR,O_READ, mountPoint);
  if(file == 0){
    Print("Allocate file failed.\n");
    return -1;
  }
  *pDir = file;
  return 0;
}

/*
 * Seek to a position in file. Should not seek beyond the end of the file.
 */
int GOSFS_Seek(struct File *file, ulong_t pos) {
  //TODO("GeekOS file system Seek operation");
  return -1;
}

/*
 * Delete the given file.
 * Return > 0 on success, < 0 on failure.
 */
int GOSFS_Delete(struct Mount_Point *mountPoint, const char *path) {
  //TODO("GeekOS file system Delete operation");
    return -1;
}

/*
 * Read a directory entry from an open directory.
 * Return > 0 on success, < 0 on failure.
 */
int GOSFS_Read_Entry(struct File *dir, struct VFS_Dir_Entry *entry) {
  //TODO("GeekOS file system Read Directory operation");
  return -1;
}

static struct Filesystem_Ops s_gosfsFilesystemOps = {
    &GOSFS_Format,
    &GOSFS_Mount,
};

int GOSFS_SetSetUid(struct Mount_Point *mountPoint, const char *path, int setUid){
char *suff=0, prefix[1024];
  GOSFSsuperblock *s_block;
  GOSFSfileNode parentNode;
  GOSFSdirectory *currDir, *createD;
  int flag = 0, i, bitNum, parentBit, j;
  if(setUid != 0 && setUid != 1)
    return -1;

  //start at root directory
  s_block = Malloc(BLOCK_SIZE);
  if(s_block == 0)
    return -1;
	memset(s_block, '\0', BLOCK_SIZE);
  currDir = Malloc(BLOCK_SIZE);
  if(currDir == 0)
    return -1;
      memset(currDir, '\0', BLOCK_SIZE);
  if(readBlock(mountPoint->dev, 0, s_block)< 0)
    return -1;
  //Start at root directory
  parentBit = s_block->rootDir;
  parentNode = s_block->rootFN;
  if(readBlock(mountPoint->dev, parentBit, currDir) < 0)
    return -1;
  if(strlen(path) >= 1024)
    return -1;
  strcpy(suff, path);
  if(strcmp("/", path) == 0){
    s_block->rootFN.isSetUid = setUid;
    if(writeBlock(mountPoint->dev, 0, s_block) < 0)
      return -1;
    Free(s_block);
    Free(currDir);
    return 0;
  }
  while(Unpack_Path(suff, prefix, &suff)){
    if(strcmp("/", suff) == 0)
      break;
    //Get filenode's directory struct
    /*
      Find prefix in curr directory
      -Look in blocks[0] for an existing directory. 
      -If exists, return -1 if it is a file, or set as new directory.
      -If doesnt exist, create a directory.
    */
	//Print("%s\n", prefix);
    for(i = 0; i < MAX_FILES_PER_DIR; i++){
      if(currDir->files[i].isUsed){
	if(strcmp(currDir->files[i].name, prefix) == 0){
	  if(currDir->files[i].isDirectory == 0)
	    return -1;
	  else{
	    flag = 1;
	    parentBit = currDir->files[i].blocks[0];
	    parentNode=  currDir->files[i];
	    readBlock(mountPoint->dev, currDir->files[i].blocks[0], currDir);
	    break;	
	  }
	}
      }
    }
  }
  if(flag == 0)
    return -1; //name does not exist
  currDir->files[i].isSetUid = setUid;
  writeBlock(mountPoint->dev, parentBit, currDir);
}

int GOSFS_SetAcl(struct Mount_Point *mountPoint, const char *path, int user, int permissions){
 char *suff=0, prefix[1024];
  GOSFSsuperblock *s_block;
  GOSFSfileNode parentNode;
  GOSFSdirectory *currDir, *createD;
  int i, bitNum, parentBit, j=0;
  Print("SetAcl, %s, %d, %d\n", path, user, permissions);
  Print("%s", path);
  if(user < 0){
    return -1;
  }
  if(!(permissions & O_READ || permissions & O_WRITE || permissions & O_OWNER || permissions & 0)){
    Print("Fails 1.");
    return -1;
  }
  //start at root directory
  s_block = Malloc(BLOCK_SIZE);
  if(s_block == 0)
    return -1;
  memset(s_block, '\0', BLOCK_SIZE);
  currDir = Malloc(BLOCK_SIZE);
  if(currDir == 0)
    return -1;
  memset(currDir, '\0', BLOCK_SIZE);
  if(readBlock(mountPoint->dev, 0, s_block)< 0)
    return -1;
  //Start at root directory
  parentNode = s_block->rootFN;
  parentBit = 1;
  if(readBlock(mountPoint->dev, parentBit, currDir) < 0)
    return -1;

  strcpy(suff, path);
  Print("Looks for acls at uid: %d\n", user);
  //Adding acl's to root directory
  if(strcmp(path, "/") == 0){
    int uidFound = 0;
    int freeFlag = 0;
    //Search acls for user passed in.
    for(j = 0; j < VFS_MAX_ACL_ENTRIES; j++){
      if(parentNode.acls[j].uid != 0){
	if(parentNode.acls[j].uid == user){
	  parentNode.acls[j].permission = permissions;
	  uidFound = 1;
	  break;
	}
      }
    }
    //acls for user not found. Add to acls if permitted
    if(!uidFound){
      if(g_currentThread->userContext->uid == 0){
	for(j = 1; j < VFS_MAX_ACL_ENTRIES; j++){
	  if(parentNode.acls[j].uid == 0){
	    parentNode.acls[j].uid = user;
	    parentNode.acls[j].permission = permissions;
	    freeFlag = 1;
	  }
	}
      }else
	return -1;
    }
    if(!freeFlag){
      Print("acls table is full.\n");
      return -1;
    }
  }

  int found = 0;
  //Traverses directory to find the parent directory for the file.
  while(Unpack_Path(suff, prefix, &suff)){
    if(strcmp(suff, "/") == 0) 
      break; 
    //Get filenode's directory struct
    /*
      Find prefix in curr directory
      -Look in blocks[0] for an existing directory. 
    */
    //Print("%s\n", prefix);
    for(i = 0; i < MAX_FILES_PER_DIR; i++){
      if(currDir->files[i].isUsed){
				if(strcmp(currDir->files[i].name, prefix) == 0){
					if(currDir->files[i].isDirectory == 0)
						return -1;
					else{
						found = 1;
						parentBit = currDir->files[i].blocks[0];
						parentNode = currDir->files[i];
						readBlock(mountPoint->dev, currDir->files[i].blocks[0], currDir);
						break;	
					}
				}
      }
    }
    if(found == 0)
      return -1; //name does not exist
  }
  Print("filename: %s\n", prefix);
  found = 0;
  for(i = 0; i < MAX_FILES_PER_DIR; i++){
    if(currDir->files[i].isUsed){
      //Something exists
      if(strcmp(currDir->files[i].name, prefix) == 0){
	found = 1;
	break;
      }				
    }
  }
  if(found == 0){
    Print("File does not exist");
    return -1;
  }
  Print("File found\n");
  //find acls
  int uidFound = 0;
  int emptyFlag = 0;
  Print("permission: %d, current uid: %d, owner's uid: %d, user: %d\n", permissions, g_currentThread->userContext->uid, currDir->files[i].acls[0].uid, user);
  if(permissions & O_OWNER){
	if(g_currentThread->userContext->uid == 0 || g_currentThread->userContext->uid == currDir->files[i].acls[0].uid){
		currDir->files[i].acls[0].uid = user;
	}else{
		Print("uid not allowed to set permission to owner.\n");
		return -1;
	}
  }else{
	  for(j = 0; j < VFS_MAX_ACL_ENTRIES; j++){
		if(currDir->files[i].acls[j].uid != 0){
		  if(currDir->files[i].acls[j].uid == user){
					currDir->files[i].acls[j].permission = permissions;
					uidFound = 1;
					break;
		  }
		}
	  }
	  if(!uidFound){
		Print("uid not found\n");
		if(g_currentThread->userContext->uid == 0 || g_currentThread->userContext->uid == currDir->files[i].acls[0].uid){
		  //Find empty acl slot
				Print("Find empty slot\n");
		  for(j = 1; j < VFS_MAX_ACL_ENTRIES; j++){
					if(currDir->files[i].acls[j].uid == 0){
						Print("j: %d\n", j);
						currDir->files[i].acls[j].uid = user;
						currDir->files[i].acls[j].permission = permissions;
						emptyFlag = 1;
						break;
					}
		  }
		  if(!emptyFlag){
					Print("acls has no more room\n");
					return -1;
		  }
		}else{
		  Print("Not authorized to set acl to current directory.\n");
		  return -1;
		} 
	  }
	}
  Print("j:%d, uid:%d\n", j, currDir->files[i].acls[j].uid);
  if(writeBlock(mountPoint->dev, parentBit, currDir) < 0){
    Print("Write back to memory failed");
    return -1;
  }
  return 0;

}

/* ----------------------------------------------------------------------
 * Public functions
 * ---------------------------------------------------------------------- */

void Init_GOSFS(void) {
    Register_Filesystem("gosfs", &s_gosfsFilesystemOps);
}
